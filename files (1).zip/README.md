# 🛒 SAP OTC Consultant — Order-to-Cash End-to-End Project

**Capstone Project | KIIT | SAP OTC (Order-to-Cash) Consultant Track**

---

## 📌 Project Overview

This project implements the **complete Order-to-Cash (O2C) business cycle** in SAP SD for a fictitious company — **TechNova Trading Pvt. Ltd.** — a B2B electronics trading company based in Pune, India.

The project covers all 10 steps of the O2C cycle, from Customer Inquiry to Payment Clearing, including full SAP SD configuration, Master Data setup, and step-by-step transaction execution with accounting entries.

---

## 🏢 Company Details

| Field | Value |
|---|---|
| Company | TechNova Trading Pvt. Ltd. |
| Company Code | TN01 |
| Industry | Electronics Trading (B2B) |
| Sales Organization | TN10 — Pune |
| Currency | INR |
| Fiscal Year | April – March (India) |

---

## 🎯 Problem Statement

Before SAP, TechNova faced:
- ❌ Manual order processing via email/phone — no system of record
- ❌ No real-time credit enforcement — bad debt risk
- ❌ Disconnected warehouse — no visibility of confirmed orders
- ❌ Delayed billing — invoices raised 5–7 days after delivery
- ❌ 10–12 day month-end close due to manual reconciliation

**Solution:** Full O2C implementation in SAP SD integrated with SAP FI and SAP MM.

---

## 🔄 O2C Process Flow — 10 Steps

```
[Customer Inquiry]          VA11
        ↓
[Quotation]                 VA21
        ↓
[Sales Order]               VA01
        ↓
[Credit Check / Release]    VKM1 / FD32
        ↓
[Outbound Delivery]         VL01N
        ↓
[Picking & Packing]         LT0A / VL02N
        ↓
[Post Goods Issue (PGI)]    VL02N  →  FI: DR COGS / CR Inventory
        ↓
[Billing / Invoice]         VF01   →  FI: DR Receivable / CR Revenue + GST
        ↓
[Invoice Output (Email)]    VF02 / VF31
        ↓
[Payment & Clearing]        F-28   →  FI: DR Bank / CR Receivable
```

---

## 💡 Key Features of This Project

| Feature | Details |
|---|---|
| 🏗️ Full Org Structure | Company Code, Sales Org, Distribution Channel, Division, Plant, Shipping Point |
| 👤 Customer Master | XD01 — with Partner Functions, Credit Limit, Payment Terms, Tax Classification |
| 📦 Material Master | MM01 — FERT type with all SD-relevant views |
| 💰 Pricing Procedure | TNPR01 — Base Price + Customer Discount + GST 18% + Cash Discount |
| 🛡️ Credit Management | Automatic credit check, block, and release workflow (VKM1 / FD32) |
| 🚚 Delivery & WM | Outbound Delivery + Transfer Order for physical picking |
| 📄 Billing & FI | Invoice with automatic accounting: Revenue, Tax, Receivables |
| 💳 Payment Clearing | F-28 — Full open item clearing with zero balance confirmation |
| 📊 Document Flow | Complete audit trail: Inquiry → Quotation → Order → Delivery → Invoice → Payment |

---

## ⚙️ SAP Configuration (SPRO)

| Area | Configuration Done |
|---|---|
| Enterprise Structure | Company Code, Sales Org, Distribution Channel, Division, Plant, Shipping Point |
| Sales Document Types | OR (Standard Order), QT (Quotation), IN (Inquiry) |
| Item & Schedule Lines | TAN + CP — Standard item with MRP and delivery |
| Pricing | Procedure TNPR01, Condition Types PR00, K007, MWST, SKTO |
| Credit Management | Automatic credit check for Sales Orders |
| Copy Control | QT→OR, OR→LF, LF→F2 |
| Output | RD00 Invoice output via email (Smart Forms) |
| Account Determination | VKOA — Revenue 800000, Tax 220100, AR 140000 |

---

## 💰 Sample Transaction — Business Scenario

**Customer:** Raj Electronics Pvt. Ltd.
**Order:** 20 units of Smart LED TV 55 Inch 4K @ INR 42,000

| Step | Amount (INR) |
|---|---|
| Base Price (20 × 42,000) | 8,40,000 |
| Customer Discount 8% | – 67,200 |
| Net Value | 7,72,800 |
| GST @ 18% | + 1,39,104 |
| **Total Invoice Value** | **9,11,904** |

**PGI Entry:** DR COGS 6,20,000 / CR Inventory 6,20,000
**Billing Entry:** DR AR 9,11,904 / CR Revenue 7,72,800 + CR GST 1,39,104
**Payment Entry:** DR Bank 9,11,904 / CR AR 9,11,904

---

## 🗂️ Project Structure

```
sap-otc-consultant-project/
│
├── docs/
│   └── SAP_OTC_Project_Documentation.docx   ← Full project report
│
└── README.md                                 ← This file
```

---

## ⚙️ Tech Stack

| Component | Details |
|---|---|
| ERP System | SAP ECC 6.0 / SAP S/4HANA 2023 |
| Primary Module | SAP SD — Sales & Distribution |
| Integrated Modules | SAP FI, SAP MM, SAP WM |
| Configuration | SPRO — SAP Implementation Guide |
| Credit Management | FI-AR Credit Management |
| Output | SAP Smart Forms — Invoice PDF |
| Certification | SAP OTC Consultant / C_TS462 — SAP S/4HANA Sales |

---

## 👤 Author

| Field | Details |
|---|---|
| Name | [Your Full Name] |
| Roll No. | [Your Roll Number] |
| Batch / Program | [Your Batch Name] |
| Institute | KIIT |
| Submission Date | April 21, 2026 |

---

## 🚀 Future Improvements

- Returns Order (RE) & Credit Memo process
- Rebate Management (VBO1) for volume discounts
- SAP CRM integration for Lead-to-Order
- Dunning (F150) for automated payment reminders
- EDI / IDoc for auto Sales Order creation
- SAP S/4HANA Fiori Apps for mobile O2C dashboard
